package com.service;
 
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
 
import com.entity.Book;
import com.entity.Comments;
import com.entity.Likes;
import com.entity.Review;
import com.entity.Customer;
import com.repository.BookRepository;
import com.repository.LikesRepository;
import com.repository.ReviewRepository;
import com.repository.CustomerRepository;
@Service
public class BookService  {
	@Autowired
	BookRepository bookRepository;
	@Autowired
	LikesRepository likesRepository;
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	ReviewRepository reviewRepository;
	
//	add book 
	public Book addBook(Book book) {
		return bookRepository.save(book);
	}
 
//	modify book
	public Book modifyBook(Book book) {
		System.out.println("book  "+book);
		Book modifiedBook=bookRepository.findById(book.getBookId()).orElse(null);
		System.out.println("Modified "+modifiedBook);
		modifiedBook.setIsbn(book.getIsbn());
		modifiedBook.setTitle(book.getTitle());
		modifiedBook.setAuthor(book.getAuthor());
		modifiedBook.setYear(book.getYear());
		modifiedBook.setPrice(book.getPrice());
		modifiedBook.setSeller(book.getSeller());
		modifiedBook.setDescription(book.getDescription());
		modifiedBook.setComments(book.getComments());
		modifiedBook.setLikes(book.getLikes());
		return bookRepository.save(modifiedBook);
	}
	public Book removeBook(int bookId) {
		Optional<Book> optionalBook = bookRepository.findById(bookId);
		bookRepository.deleteById(bookId);
		Book book = optionalBook.get();
		return book;
	}
	public Book getBookById(int bookId) {
		Optional<Book> optionalBook = bookRepository.findById(bookId);
		Book book = optionalBook.get();
		return book;
	}
	public List<Book> getAllBooks(){
		List<Book> bookList= bookRepository.findAll();
		return bookList;
	}
	public Book addLike(int CustomerId,int bookId) {
		Book book = bookRepository.findById(bookId).orElse(null);
		Customer Customer = customerRepository.findById(CustomerId).orElse(null);
		if(book == null || Customer == null)return null;
		List<Likes> likeList= book.getLikes();
		if(likeList==null) {
			likeList= new ArrayList<Likes>();
		}
		boolean anyMatch= likeList.stream().anyMatch(like -> like.getLikedCustomer().getCustomerId() == Customer.getCustomerId());
		if(!anyMatch) {
		Likes newLike = new Likes();
		newLike.setLikedCustomer(Customer);
		newLike.setTime(LocalDateTime.now());
		likeList.add(newLike);
		book.setLikes(likeList);
		}
		return bookRepository.save(book);
	}
	public Book removeLike(int CustomerId,int bookId) {
		Book book = bookRepository.findById(bookId).orElse(null);
		Customer Customer = customerRepository.findById(CustomerId).orElse(null);
		if(book == null || Customer == null || book.getLikes()==null)return null;
		Likes likeToBeRemoved=null;
		List<Likes> likeList = book.getLikes();
		boolean matchCheck= book.getLikes().stream().anyMatch(like -> like.getLikedCustomer().getCustomerId() == Customer.getCustomerId());
		if(matchCheck) {
		for(Likes like:book.getLikes()) {
			if(like.getLikedCustomer().getCustomerId()==Customer.getCustomerId()) {
				likeToBeRemoved=like;
				likeList.remove(likeToBeRemoved);
				book.setLikes(likeList);
				likesRepository.deleteById(likeToBeRemoved.getLikeId());
				return bookRepository.save(book);
			}
		}
	}
	return book;
	}
	public Book addComment(int customerId,int bookId,String commentText) {
		Book book = bookRepository.findById(bookId).orElse(null);
		Customer Customer = customerRepository.findById(customerId).orElse(null);
		if (book == null || Customer == null) 
			{
			return null;
			}
	    Comments comment = new Comments();
	    comment.setCustomer(Customer); 
	    comment.setComment(commentText); 
	    comment.setCommentTime(LocalDateTime.now()); 

	    List<Comments> commentList = book.getComments();
	    if (commentList == null) {
	        commentList = new ArrayList<>(); 
	    }

	    commentList.add(comment);
	    book.setComments(commentList);

	    return bookRepository.save(book);
	}
	public Book removeComment(int userId,int bookId, int commentId) {
		 Book book = bookRepository.findById(bookId).orElse(null);
		 Customer customer = customerRepository.findById(userId).orElse(null);
		    if (book == null || customer == null) {
		        return null;
		    }
 
		    List<Comments> commentList = book.getComments();
		    if (commentList != null) {
		        Comments commentToRemove = commentList.stream()
		                .filter(comment -> comment.getCommentId() == commentId && comment.getCustomer().getCustomerId() == userId)
		                .findFirst()
		                .orElse(null);
		        if (commentToRemove != null) {
		            commentList.remove(commentToRemove);
		            book.setComments(commentList);
		            return bookRepository.save(book);
		        }
		    }
 
		    return null;
	}
	
	
	public Review addReview(int customerId,int bookId,String reviewText,int rating) {
		 
	    Customer existingCustomer = customerRepository.findById(customerId).orElse(null);
	    Book book = bookRepository.findById(bookId).orElse(null);
	    if(book==null) 
	    	return null;
	    List<Review> reviewList=book.getReviewList();
	    Review review= null;
	    System.out.println("customer ======> ");
	    boolean newReview=true;
	    for(Review reviewIterator:reviewList) {
	    	if(reviewIterator.getCustomer().getCustomerId()==customerId) {
	    		review=reviewIterator;
	    		newReview=false;
	    	}
	    }
	    if(review == null) review = new Review();
	    
	    if (existingCustomer != null) {
	        review.setCustomer(existingCustomer);
	        review.setReviewText(reviewText);
	        review.setRating(rating);
	        if(newReview)
	        	reviewList.add(review);
		    book.setReviewList(reviewList);
		    System.out.println("review ====================> "+review);
		    System.out.println("book ======================> "+book);
		    bookRepository.save(book);
		    return reviewRepository.save(review);
	    } 
	    return review;
	}
	
		public Book removeReview(int userId,int bookId, int reviewId) {
	//		 Book book = bookRepository.findById(bookId).orElse(null);
	//		 Customer customer = customerRepository.findById(userId).orElse(null);
	//
	//		    if (book == null || customer == null) {
	//		        return null;
	//		    }
	//
	//		    List<Review> reviewList = book.getReviewList();
	//		    if (reviewList != null) {
	//		        Review reviewToRemove = reviewList.stream()
	//		                .filter(review -> review.getReviewId()  == reviewId && review.getCustomer().getCustomerId() == userId)
	//		                .findFirst()
	//		                .orElse(null);
	//		        if (reviewToRemove != null) {
	//		        	book.setReviewList(reviewList);
	//		        	Book booktoBeReturned=bookRepository.save(book);
	//		            reviewList.remove(reviewToRemove);
	//		            
	//		            return booktoBeReturned;
	//		        }
	//		    }
	//
	//		    return null;
			
			 Book book = bookRepository.findById(bookId).orElse(null);
			 Customer customer = customerRepository.findById(userId).orElse(null);
			    if (book == null || customer == null) {
			        return null;
			    }
	
			    List<Review> reviewList = book.getReviewList();
			    if (reviewList != null) {
			        Review reviewToRemove = reviewList.stream()
			                .filter(review -> review.getReviewId() == reviewId && review.getCustomer().getCustomerId() == userId)
			                .findFirst()
			                .orElse(null);
			        if (reviewToRemove != null) {
			        	reviewList.remove(reviewToRemove);
			            book.setReviewList(reviewList);
			            return bookRepository.save(book);
			        }
			    }
	
			    return null;
		}
		
		
		
		public List<Book> getBookByTitle(String title) {
		return bookRepository.getBookByTitle(title);
	}
	public List<Book> getBookByAuthor(String author) {
		return bookRepository.getBookByAuthor(author);
	}

 
	public List<Book> getBookByYear(int year) {
		return bookRepository.getBookByYear(year);
	}

	public List<Book> getBookBySeller(String seller) {
		return bookRepository.getBookBySeller(seller);
	}

}