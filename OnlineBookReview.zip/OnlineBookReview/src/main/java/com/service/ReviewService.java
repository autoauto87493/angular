package com.service;
 
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
 
import com.entity.Customer;
import com.entity.Review;
import com.repository.CustomerRepository;
import com.repository.ReviewRepository;
 
@Service
public class ReviewService {
 
	@Autowired
	ReviewRepository reviewRepository;
	@Autowired
	CustomerRepository customerRepository;
	
	public Review modifyReview(Review review) {
		return reviewRepository.save(review);
	}
	public Review deleteReview(int reviewId) {
		Review review=reviewRepository.findById(reviewId).orElse(null);
		reviewRepository.deleteById(reviewId);
		return review;
	}
	public List<Review> getAllReviews(){
		return reviewRepository.findAll();
	}
	public Customer getCustomerByReviewId(int reviewId) {
		Review review= reviewRepository.findById(reviewId).orElse(null);
		return review.getCustomer();
	}
}