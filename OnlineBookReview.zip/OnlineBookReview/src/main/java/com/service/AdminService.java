package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Admin;
import com.repository.AdminRepositoy;

@Service
public class AdminService {
	@Autowired
	AdminRepositoy adminRepositoy;
	
	public Admin add(Admin admin) {
		return adminRepositoy.save(admin);
	}
	
	public Admin update(Admin admin) {
		return adminRepositoy.save(admin);
	}
	
}
