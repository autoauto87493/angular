package com.restController;
 
import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import com.entity.Book;
import com.entity.Review;
import com.service.BookService;
import org.springframework.web.bind.annotation.RequestParam;
 
 
 
@CrossOrigin("*")
@RestController
@RequestMapping("/book")
public class BookRestController {
	@Autowired
	BookService bookService;
	@PostMapping("/add")
	public Book addBook(@RequestBody Book book) {
		return bookService.addBook(book);
	}
	@PutMapping("/modify")
	public Book modifyBook(@RequestBody Book book) {	
		return bookService.modifyBook(book);
	}
	@DeleteMapping("/remove/{bookId}")
	public Book removeBook(@PathVariable("bookId") int bookId) {
		return bookService.removeBook(bookId);
	}
	@GetMapping("/get/{bookId}")
	public Book searchBook(@PathVariable("bookId") int bookId) {
		return bookService.getBookById(bookId);
	}
	@GetMapping("/getAll")
	public List<Book> getAllBooks(){
		return bookService.getAllBooks();
	}
	@DeleteMapping("/remove/like/{userId}/{bookId}")
	public Book removeLike(@PathVariable("userId") int userId,@PathVariable("bookId") int bookId) {
		return bookService.removeLike(userId, bookId);
	}
	@GetMapping("/add/like/{userId}/{bookId}")
	public Book addLike(@PathVariable("userId") int userId,@PathVariable("bookId") int bookId) {
		return bookService.addLike(userId, bookId);
	}
	@PostMapping("/add/comment/{userId}/{bookId}")
	public Book addComment(@PathVariable("userId")int userId,@PathVariable("bookId") int bookId,@RequestParam("comment") String commentText) {
		return bookService.addComment(userId, bookId,commentText);
	}
	@DeleteMapping("/remove/comment/{userId}/{bookId}/{commentId}")
	public Book removeComment(@PathVariable("userId") int userId,@PathVariable("bookId") int bookId,@PathVariable("commentId") int commentId) {
		return bookService.removeComment(userId, bookId,commentId);
	}
	@GetMapping("/getbookbytitle/{title}")
	public List<Book> getBookByTitle(@PathVariable("title") String title) {
		return bookService.getBookByTitle(title);
	}
	@GetMapping("/getbookbyauthor/{author}")
	public List<Book> getBookByAuthor(@PathVariable("author") String author) {
		return bookService.getBookByAuthor(author);
	}
	@GetMapping("/getbookbyyear/{year}")
	public List<Book> getBookByYear(@PathVariable("year") int year) {
		return bookService.getBookByYear(year);
	}
	@GetMapping("/getbookbyseller/{seller}")
	public List<Book> getBookBySeller(@PathVariable("seller") String seller) {
		return bookService.getBookBySeller(seller);
	}
	@PostMapping("/addorupdatereview")
	public Review addReview(@RequestParam("custId") int customerId,@RequestParam("bookId") int bookId,@RequestParam("reviewText") String reviewText,@RequestParam("rating")int rating) {
		return bookService.addReview(customerId, bookId, reviewText, rating);
	}
	@DeleteMapping("/removereview")
	public Book removeReview(@RequestParam("userId") int userId,@RequestParam("bookId") int bookId,@RequestParam("reviewId")  int reviewId) {
		return bookService.removeReview(userId, bookId, reviewId);
	}

}