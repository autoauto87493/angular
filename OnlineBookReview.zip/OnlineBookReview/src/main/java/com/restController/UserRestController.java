package com.restController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Authorizer;
import com.entity.Customer;
import com.entity.User;
import com.service.UserService;



@CrossOrigin("*")
@RestController
@RequestMapping("/user")
public class UserRestController {
	
	@Autowired
	UserService userService;
	
	@PostMapping("/login")
	public Authorizer login(@RequestBody User user) {
		return userService.login(user);
	}
	@GetMapping("/getCustomer/{id}")
	public Customer getById(@PathVariable("id") int id) {
		return userService.getCustomer(id);
	}
	@PutMapping("/customer/update")
	public boolean update(@RequestBody Customer customer) {
		return userService.update(customer);
	}
}
