package com.restController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.service.annotation.PutExchange;

import com.entity.Customer;
import com.service.CustomerService;


@CrossOrigin("*")
@RestController
@RequestMapping("/customer")
public class CustomerRestController {
	@Autowired
	CustomerService userService;
	@PostMapping("/add")
	public Customer addUser(@RequestBody Customer customer) {
		return userService.addCustomer(customer);
	}
	@PutMapping("/update")
	public Customer updateUser(@RequestBody Customer customer) {
		return userService.updateCustomer(customer);
	}
	@GetMapping("/getall")
	public List<Customer> getAllUsers(){
		return userService.getAllCustomers();
	}
}
