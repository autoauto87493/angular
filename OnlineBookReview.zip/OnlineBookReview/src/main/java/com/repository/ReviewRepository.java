package com.repository;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
 
import com.entity.Customer;
import com.entity.Review;
 
@Repository
public interface ReviewRepository extends JpaRepository<Review, Integer>{
 
	@Query("SELECT  r.customer FROM Review r WHERE r.reviewId=:reviewIdForCustomer")
	public Customer getCustomerByReviewId(@Param("reviewIdForCustomer") int reviewId);
	@Query("SELECT r FROM Review r WHERE r.customer.customerId=:customerIdForReview")
	public Review getReviewByCustomerId(@Param("customerIdForReview") int customerIdForReview);
}



