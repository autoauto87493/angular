import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { AdminComponent } from './components/admin/admin.component';
import { NavigationBarComponent } from './components/navigation-bar/navigation-bar.component';
import { GuardService } from './service/guard.service';
import { AdminNavigationComponent } from './components/admin-navigation/admin-navigation.component';
import { RoleManagerComponent } from './components/role-manager/role-manager.component';
import { AddBookComponent } from './components/add-book/add-book.component';
import { AdminBookNavigationComponent } from './components/admin-book-navigation/admin-book-navigation.component';
import { SearchBookByAuthorComponent } from './components/search-book-by-author/search-book-by-author.component';
import { SearchBookBySellerComponent } from './components/search-book-by-seller/search-book-by-seller.component';
import { SearchBookByTitleComponent } from './components/search-book-by-title/search-book-by-title.component';
import { SearchBookByYearComponent } from './components/search-book-by-year/search-book-by-year.component';
import { AdminViewBookComponent } from './components/admin-view-book/admin-view-book.component';
import { EditBookComponent } from './components/edit-book/edit-book.component';
import { CustomerBookNavigationComponent } from './components/customer-book-navigation/customer-book-navigation.component';
import { AuthenticationService } from './service/authentication.service';
import { CustomerViewIndividualBookComponent } from './components/customer-view-individual-book/customer-view-individual-book.component';
import { CustomerSearchBookByAuthorComponent } from './components/customer-search-book-by-author/customer-search-book-by-author.component';
import { CustomerSearchBookBySellerComponent } from './components/customer-search-book-by-seller/customer-search-book-by-seller.component';
import { CustomerSearchBookByYearComponent } from './components/customer-search-book-by-year/customer-search-book-by-year.component';
import { CustomerSearchBookByTitleComponent } from './components/customer-search-book-by-title/customer-search-book-by-title.component';
import { AdminProfileComponent } from './components/admin-profile/admin-profile.component';
import { EditAdminProfileComponent } from './components/edit-admin-profile/edit-admin-profile.component';
const routes: Routes = [
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'home',
    component:HomeComponent
  },
  {
    path:'admin',
    component:AdminComponent,
    canActivate:[GuardService]
  },
  {
    path:"",
    component:RoleManagerComponent
  },
  {
    path:'nav',
    component:NavigationBarComponent
  },
  {
    path:'adminnav',
    component:AdminNavigationComponent
  },
  {
    path:'addbook',
    component:AddBookComponent,
    canActivate:[GuardService]
  },
  {
    path:'adminbooknav',
    component:AdminBookNavigationComponent,
    canActivate:[GuardService]
  },
  {
    path:'searchbookbyauthor',
    component:SearchBookByAuthorComponent,
    canActivate:[GuardService]
  },
  {
    path:'searchbookbyseller',
    component:SearchBookBySellerComponent,
    canActivate:[GuardService]
  },

  {
    path:'searchbookbyyear',
    component:SearchBookByYearComponent,
    canActivate:[GuardService]
  },

  {
    path:'searchbookbytitle',
    component:SearchBookByTitleComponent,
    canActivate:[GuardService]
  },

  {
    path:'adminviewbook',
    component:AdminViewBookComponent,
    canActivate:[GuardService]
  },
  {
    path:"editbook",
    component:EditBookComponent,
    canActivate:[GuardService]
  },
  {
    path:'book',
    component:CustomerBookNavigationComponent,
  },
  {
    path:'individualbook',
    component:CustomerViewIndividualBookComponent
  },
  {
    path:'customersearchbookbyauthor',
    component:CustomerSearchBookByAuthorComponent
  },
  {
    path:'customersearchbookbyseller',
    component:CustomerSearchBookBySellerComponent
  },

  {
    path:'customersearchbookbyyear',
    component:CustomerSearchBookByYearComponent
  },

  {
    path:'customersearchbookbytitle',
    component:CustomerSearchBookByTitleComponent
  },

  {
    path:'adminprofile',
    component:AdminProfileComponent
  },

  {
    path:'editadminprofile',
    component: EditAdminProfileComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
