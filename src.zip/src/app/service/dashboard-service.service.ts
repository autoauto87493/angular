import { HttpClient } from '@angular/common/http';
import { Injectable, Optional } from '@angular/core';
import { Observable } from 'rxjs';
import { DashboardData } from '../entity/DashboardData';

@Injectable({
  providedIn: 'root'
})
export class DashboardServiceService {

  URL:string='http://localhost:9090/dashboard';
  constructor(private http:HttpClient) { }
  getMaxReviewedBook():Observable<any>{
    return this.http.get(this.URL + '/max-review-books');
  }
  getMaxLikedBook():Observable<any>{
    return this.http.get(this.URL + '/max-like-books');
  }
  getMaxCommentedBook():Observable<any>{
    return this.http.get(this.URL + '/max-comment-books');
  }

  getAvgLikes():Observable<any>{
return this.http.get(this.URL+'/average-likes-per-book');
  }
  getTotalBook():Observable<any>{
    return this.http.get(this.URL+'/book-count');
  }
  getTotalComment():Observable<any>{
    return this.http.get(this.URL+'/comment-count');
  }
  getTotalLikes():Observable<any>{
    return this.http.get(this.URL+'/like-count');
  }
  getAllData():Observable<any>{
    return this.http.get<DashboardData>(this.URL+'/all-data');
  }
  getAllBooks(): Observable<any>{
    return this.http.get("http://localhost:9090/book/getAll");
   }
}
