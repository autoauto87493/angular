import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ImageService {

  URL :string="http://localhost:9090";
  constructor(private h:HttpClient) { }
 
   
  getAllBooks(): Observable<any>{
    return this.h.get(this.URL+"/book/getAll");
 
}
}
