import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Book } from '../entity/Book';


@Injectable({
  providedIn: 'root'
})
export class BookService {

  URL:string="http://localhost:9090/book";
  constructor(private http:HttpClient) { }
 
  addBook(book:Book):Observable<any>{
    return this.http.post(this.URL+'/add',book);
  }

  getAllBooks(): Observable<any>{
    return this.http.get(this.URL+"/getAll");
   }
  deleteBook(bookId:string):Observable<any>{
    return this.http.delete(this.URL+"/remove/"+bookId);
  }
  addLike(userId:string,bookId:string): Observable<any>{
    return this.http.get(this.URL+"/add/like/"+userId+'/'+bookId);
  }
  removeLike(userId:string,bookId:string): Observable<any>{
    return this.http.delete(this.URL+"/remove/like/"+userId+'/'+bookId);
  }
  addOrUpdateReview(customerId: string, bookId: number, reviewText: string, rating: number): Observable<any> {
    const params = new HttpParams()
      .set('custId', customerId.toString())
      .set('bookId', bookId.toString())
      .set('reviewText', reviewText)
      .set('rating', rating.toString());

    return this.http.post(`${this.URL}/addorupdatereview`, {}, { params });
}
}
