import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Authorizer } from '../entity/Authorizer';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { TempUser } from '../entity/TempUser';
import { Customer } from '../entity/Customer';
import { Admin } from '../entity/Admin';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  url: string = "http://localhost:9090";
  auth: Authorizer = new Authorizer();

  constructor(private h: HttpClient, private router: Router) {}

  canActivate(): boolean {
    let temp = sessionStorage.getItem("token");
    if (temp == null || temp.localeCompare("failed")==0) {
      this.router.navigate(['/login']);
      return false;
    }
    if(sessionStorage.getItem('token')==='customer'){
      return true
    }
    return false;
  }

  login(user: TempUser): Observable<any> {
    console.log("auth service "+user.email+" "+user.password);
    return this.h.post("http://localhost:9090/user/login", user,{responseType:"json"});
    
  }

  logout(): void {
    sessionStorage.removeItem("token");
    sessionStorage.removeItem("username");
    this.router.navigate(['/']); // Navigate back to login on logout
  }
  getUser(id:string):Observable<any>{
    return this.h.get('http://localhost:9090/user/getCustomer/'+id);
  }
  update(cust:Customer):Observable<any>{
    return this.h.put("http://localhost:9090/user/customer/update",cust);
  }
  addAdmin(admin:Admin):Observable<any>{
    return this.h.post('http://localhost:9090/admin/add',admin,{responseType:"json"});
  }
  addCustomer(customer:any):Observable<any>{
    return this.h.post('http://localhost:9090/customer/add',customer);
  } 
}
