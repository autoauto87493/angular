import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerViewBookComponent } from './customer-view-book.component';

describe('CustomerViewBookComponent', () => {
  let component: CustomerViewBookComponent;
  let fixture: ComponentFixture<CustomerViewBookComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerViewBookComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerViewBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
