import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Book } from 'src/app/entity/Book';
import { BookService } from 'src/app/service/book.service';

@Component({
  selector: 'app-customer-view-book',
  templateUrl: './customer-view-book.component.html',
  styleUrls: ['./customer-view-book.component.css']
})
export class CustomerViewBookComponent {
  statusForViewInd: boolean=false;
  statusForView: boolean=true;
  flag:number=3;
  
  books:Book[]=[];
  
  constructor(private router:Router,private bookService:BookService){}
  
  deletedBook:Book=new Book();
  sortByPrice(){
    this.flag=1;
  }
  sortByYear() {
    this.flag=5;
  }
  sortByAuthor() {
    this.flag=4;
  }
  sortByTitle() {
    this.flag=3;
  }
  sortByRating() {
    this.flag=2;
  }
  viewBook(book: Book) {
  sessionStorage.setItem('viewBook',JSON.stringify(book));
  this.statusForViewInd=true;
  this.statusForView=false;
  }
  
  
  ngOnInit(){
    this.getBooks();
    }
  
    getBooks(){
      this.bookService.getAllBooks().subscribe(
        (data: Book[]) => {
          this.books = data;
         
        },
        (error: any) => {
          console.error('Error fetching books:', error);
        }
      );
    }

}
