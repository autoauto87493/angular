import { Component } from '@angular/core';
import { Book } from 'src/app/entity/Book';
import { Review } from 'src/app/entity/Review';
import { BookService } from 'src/app/service/book.service';

@Component({
  selector: 'app-customer-view-individual-book',
  templateUrl: './customer-view-individual-book.component.html',
  styleUrls: ['./customer-view-individual-book.component.css']
})
export class CustomerViewIndividualBookComponent {
reviewText: string='';
comment: string='';
submitReview() {
  this.bookService.addOrUpdateReview(this.customerId,this.book.bookId, this.reviewText, this.rating).subscribe((response)=>{

  });
}
  constructor(private bookService:BookService){}
  hidereview:boolean=true;
  book:Book=new Book();
  reviews:Review[] = [];
  showReview: boolean = false;
  customerId:string='';
  rating:number=0;
  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    let str:string|null=sessionStorage.getItem('viewBook');
    if(str){
      this.book=JSON.parse(str);
      this.reviews=this.book.reviewList;
    }
    let temp1:string|null=sessionStorage.getItem("userId");
    if(temp1){
      this.customerId=temp1;
    }
    
  }

  isLiked: boolean = false;
      isCommentVisible: boolean = false;
   
      likeBook() {
          // this.isLiked = !this.isLiked;
          if(this.isLiked){
            this.bookService.removeLike(this.customerId,this.book.bookId.toString()).subscribe((res)=>{
              this.isLiked=!this.isLiked;
            });
          }
          else{
            this.bookService.addLike(this.customerId,this.book.bookId.toString()).subscribe((res)=>{
              this.isLiked=!this.isLiked;
            });
          }
          
      }
   
      toggleComment() {
          this.isCommentVisible = !this.isCommentVisible;
      }
   
      sendComment() {
        this.bookService.addComment(this.customerId,this.book.bookId,this.comment).subscribe(()=>{});
      }
      
  rateBook(star: number) {
    this.rating = star; // Set the rating based on the star clicked
  }
   
   

   showReviews() {
     this.showReview = !this.showReviews;
     if(this.hidereview){
      this.hidereview=false;
    }
    else{
      this.hidereview=true;
    }
   }
   
}
