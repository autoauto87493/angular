import { Component } from '@angular/core';
import { Book } from 'src/app/entity/Book';
import { Review } from 'src/app/entity/Review';
import { BookService } from 'src/app/service/book.service';

@Component({
  selector: 'app-admin-individual-view-book',
  templateUrl: './admin-individual-view-book.component.html',
  styleUrls: ['./admin-individual-view-book.component.css']
})
export class AdminIndividualViewBookComponent {

deleteComment(bookId: number,commentId: number,userId: number) {
this.bookService.removeComment(userId,bookId,commentId).subscribe((a)=>this.book=a);
}
    
    showComment: boolean=false;
    constructor(private bookService:BookService){}
    hidereview:boolean=true;
    book:Book=new Book();
    reviews:Review[] = [];
    showReview: boolean = false;
    
    rating:number=0;
    ngOnInit(): void {
      
      let str:string|null=sessionStorage.getItem('adminViewBook');
      if(str){
        this.book=JSON.parse(str);
        this.bookService.getBookById(this.book.bookId).subscribe((a)=>{this.book=a;   });
      }
      

    }
  
    isLiked: boolean = false;
        isCommentVisible: boolean = false;
     

     
        toggleComment() {
            this.isCommentVisible = !this.isCommentVisible;
        }
     
        
        
    rateBook(star: number) {
      this.rating = star; // Set the rating based on the star clicked
    }
    showDelete() {
this.showComment=!this.showComment;
    }
     
  
     showReviews() {
       this.showReview = !this.showReviews;
       if(this.hidereview){
        this.hidereview=false;
      }
      else{
        this.hidereview=true;
      }
     }
     deleteReview(bookId: number,reviewId:number,custId:number) {
      
      this.bookService.deleteReview(bookId,reviewId,custId).subscribe((a)=>{this.book=a;
        location.reload();
      });
      }

       
     
}
