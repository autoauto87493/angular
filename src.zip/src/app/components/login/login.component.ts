import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Authorizer } from 'src/app/entity/Authorizer';
import { TempUser } from 'src/app/entity/TempUser';
import { AuthenticationService } from 'src/app/service/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  isCustomerFormVisible = true; // Start with customer form by default
  isAdminFormVisible = false;
loginCustomer() {
  this.cust.role="customer"
  this.login(this.cust);
}
loginAdmin() {
  this.out.role="admin"
  this.login(this.out);
}
  url: string = "http://localhost:9090";
  // userId: string ='';
  // password: string='';
  out:TempUser=new TempUser();
  cust:TempUser=new TempUser();
  validUser:Authorizer=new Authorizer();
    constructor(private p:Router,private serv:AuthenticationService){  }
    
    toggleForm(formType: string) {
      if (formType === 'customer') {
        this.isCustomerFormVisible = true;
        this.isAdminFormVisible = false;
      } else if (formType === 'admin') {
        this.isCustomerFormVisible = false;
        this.isAdminFormVisible = true;
      }
    }
  ngOnInit(): void {
    if(sessionStorage.getItem('token')=="admin"){
      this.p.navigate(['/admin']);
    }
    if(sessionStorage.getItem('token')==="customer"){
      this.p.navigate(['/home']);
    }
  }
  
    gotoCust() {
  // this.p.navigate(['/signup']);
  }
  
  login(out:TempUser) {
    
    this.serv.login(out).subscribe((u) => {
      this.validUser = u;
      if (this.validUser.token.localeCompare("customer") === 0) {
        console.log("inside if block of login component");
        sessionStorage.setItem("username", out.email);
        sessionStorage.setItem("userId",this.validUser.userId);
        sessionStorage.setItem("token", this.validUser.token);
        this.p.navigate(['/home']);
      } 
      else if (this.validUser.token.localeCompare("admin") === 0) {
        sessionStorage.setItem("username", out.email);
        sessionStorage.setItem("token", this.validUser.token);
        this.p.navigate(['/admin']);
      }
      else {
       alert("Login failed");
      }
    }, error => {
      console.error("Error during login", error);
    });
  }
  
  
}
