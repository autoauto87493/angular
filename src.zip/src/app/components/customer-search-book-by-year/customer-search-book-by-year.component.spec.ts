import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerSearchBookByYearComponent } from './customer-search-book-by-year.component';

describe('CustomerSearchBookByYearComponent', () => {
  let component: CustomerSearchBookByYearComponent;
  let fixture: ComponentFixture<CustomerSearchBookByYearComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerSearchBookByYearComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerSearchBookByYearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
