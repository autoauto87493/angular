import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-admin-profile',
  templateUrl: './edit-admin-profile.component.html',
  styleUrls: ['./edit-admin-profile.component.css']
})
export class EditAdminProfileComponent {
  profileUpdated = false;
  isFormDisabled = false;
  showPasswordFields: boolean = false;
  emailIdDisable:boolean=true;
  passwordForm:FormGroup;
  constructor(private router:Router){
    this.passwordForm=new FormGroup({
      currentPassword: new FormControl("",[Validators.required,Validators.pattern("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=])[A-Za-z\\d@#$%^&+=]{8,}$")]),
      newPassword:new FormControl("",[Validators.required,Validators.pattern("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=])[A-Za-z\\d@#$%^&+=]{8,}$")]),
      reEnteredNewPassword:new FormControl("",[Validators.required,Validators.pattern("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=])[A-Za-z\\d@#$%^&+=]{8,}$")])
    });
  }
 
 
  togglePasswordFields() {
    this.showPasswordFields = !this.showPasswordFields; // Toggle the visibility
  }
  back():void{
    this.router.navigate(['/adminprofile']);
 
  }
 
  updateProfile() {
    
    this.profileUpdated = true;
    this.isFormDisabled = true;
 
    setTimeout(() => {
        this.profileUpdated = false;
    }, 3000); 
 
  
}
}
