import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Book } from 'src/app/entity/Book';
import { BookService } from 'src/app/service/book.service';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css']
})
export class AddBookComponent {
  selectedFile: File | null = null;
  book:Book=new Book();
  addedBook:Book=new Book();
  added:boolean=true;
  constructor(private bookService:BookService,private http: HttpClient){
 
  }
  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
  }
  addBook():void{
    if (this.selectedFile) {
      const formData = new FormData();
      const fileExtension = this.selectedFile.name.split('.').pop();
      const newFileName = `${this.book.isbn}.${fileExtension}`;
      console.log('assets/books/'+newFileName);
      this.book.imageLocation='assets/books/'+newFileName;
      formData.append('image', this.selectedFile, newFileName);
      this.http.post('http://localhost:3000/upload', formData).subscribe(
        (response) => {
          alert("Image uploaded");
        },
        (error) => {
          alert("Image upload failed");
        }
      );
    }
    
    this.bookService.addBook(this.book).subscribe((b)=>this.addedBook=b);
    this.added=false; 
  }
}
