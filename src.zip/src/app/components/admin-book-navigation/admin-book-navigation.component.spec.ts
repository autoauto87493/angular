import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminBookNavigationComponent } from './admin-book-navigation.component';

describe('AdminBookNavigationComponent', () => {
  let component: AdminBookNavigationComponent;
  let fixture: ComponentFixture<AdminBookNavigationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminBookNavigationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminBookNavigationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
