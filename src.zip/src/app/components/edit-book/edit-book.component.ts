import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Book } from 'src/app/entity/Book';
import { BookService } from 'src/app/service/book.service';

@Component({
  selector: 'app-edit-book',
  templateUrl: './edit-book.component.html',
  styleUrls: ['./edit-book.component.css']
})
export class EditBookComponent {
  selectedFile: File | null = null;
  book:Book=new Book();
  bookText:string|null='';
  editedBook:Book=new Book();
  edited:boolean=true;
  constructor(private bookService:BookService,private http: HttpClient){
 
  }

  ngOnInit(): void {
    this.bookText = sessionStorage.getItem('editableBook');
    if(this.bookText){
    this.book=JSON.parse(this.bookText);
  }
  }
  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
  }
  editBook():void{
    if (this.selectedFile) {
      const formData = new FormData();
      const fileExtension = this.selectedFile.name.split('.').pop();
      const newFileName = `${this.book.isbn}.${fileExtension}`;
      console.log('assets/books/'+newFileName);
      this.book.imageLocation='assets/books/'+newFileName;
      formData.append('image', this.selectedFile, newFileName);
      this.http.post('http://localhost:3000/upload', formData).subscribe(
        (response) => {
          alert("Image uploaded");
        },
        (error) => {
          alert("Image upload failed");
        }
      );
    }
    
    this.bookService.addBook(this.book).subscribe((b)=>this.editedBook=b);
    this.edited=false; 
  }

}
