import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerSearchBookByTitleComponent } from './customer-search-book-by-title.component';

describe('CustomerSearchBookByTitleComponent', () => {
  let component: CustomerSearchBookByTitleComponent;
  let fixture: ComponentFixture<CustomerSearchBookByTitleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerSearchBookByTitleComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerSearchBookByTitleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
