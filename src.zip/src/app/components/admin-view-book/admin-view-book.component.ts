import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Book } from 'src/app/entity/Book';
import { BookService } from 'src/app/service/book.service';

@Component({
  selector: 'app-admin-view-book',
  templateUrl: './admin-view-book.component.html',
  styleUrls: ['./admin-view-book.component.css']
})
export class AdminViewBookComponent {
statusForEdit: boolean=false;
statusForView: boolean=true;
editBook(book: Book) {
  this.statusForEdit=true;
  this.statusForView=false;
  sessionStorage.setItem('editableBook', JSON.stringify(book));
  
}
  
  books:Book[]=[];
  
  constructor(private router:Router,private bookService:BookService){}
  
  deletedBook:Book=new Book();
  deleteBook(n:string) {
    this.bookService.deleteBook(n).subscribe((a)=>this.getBooks());
      
  }

  ngOnInit(){
    this.getBooks();
  }

  getBooks(){
    this.bookService.getAllBooks().subscribe(
      (data: Book[]) => {
        this.books = data;
       
      },
      (error: any) => {
        console.error('Error fetching books:', error);
      }
    );
  }

}
