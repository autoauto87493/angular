import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Book } from 'src/app/entity/Book';
import { DashboardData } from 'src/app/entity/DashboardData';
import { DashboardServiceService } from 'src/app/service/dashboard-service.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})

export class AdminComponent {

  hidden:boolean=true;
  maxLikedBook:Book[]=[];
  maxCommentedBook:Book[]=[];
  maxReviewedBook:Book[]=[];
  avgLikesCount:number=0;
  likesCount:number=0;
  commentsCount:number=0;
  totalBooks:number=0;
  dashBoard:DashboardData={
    "maxReviewBooks": [
      {
        "bookId": 3,
        "isbn": 12345587,
        "title": "DeAR",
        "author": "Ravi",
        "year": 2020,
        "description": "qwertyuiop",
        "price": 2000,
        "seller": "Sriram pvt",
        "imageLocation": "assets/books/012345587.jfif",
        "likes": [],
        "comments": [],
        "reviewList": [
          {
            "reviewId": 252,
            "reviewText": "qwerty",
            "rating": 4,
            "customer": {
              "customerId": 2,
              "name": "thiru",
              "email": "thiru@gmail.com",
              "password": "1"
            }
          },
          {
            "reviewId": 302,
            "reviewText": "qhhvg gght hh",
            "rating": 3,
            "customer": {
              "customerId": 1,
              "name": "Tanish",
              "email": "tanish@gmail.com",
              "password": "1"
            }
          }
        ]
      }
    ],
    "maxLikeBooks": [
      {
        "bookId": 5,
        "isbn": 44786456,
        "title": "fkhfilh hjh",
        "author": "fjhej h",
        "year": 2020,
        "description": "yuioplkj e",
        "price": 2000,
        "seller": "Sriram pvt",
        "imageLocation": "assets/books/44786456.png",
        "likes": [
          {
            "likeId": 155,
            "likedCustomer": {
              "customerId": 1,
              "name": "Tanish",
              "email": "tanish@gmail.com",
              "password": "1"
            },
            "time": "2024-10-21T20:37:14.038154"
          }
        ],
        "comments": [],
        "reviewList": []
      }
    ],
    "maxCommentBooks": [
      {
        "bookId": 4,
        "isbn": 1234557654,
        "title": "JHFGJHFGBKJH",
        "author": "FJKB ",
        "year": 2020,
        "description": "yuioplkj",
        "price": 20,
        "seller": "Sriram pvt",
        "imageLocation": "assets/books/01234557654.png",
        "likes": [],
        "comments": [
          {
            "commentId": 1,
            "comment": "good book",
            "customer": {
              "customerId": 1,
              "name": "Tanish",
              "email": "tanish@gmail.com",
              "password": "1"
            },
            "commentTime": "2024-10-21T19:25:31.459993"
          }
        ],
        "reviewList": []
      }
    ],
    "averageLikesPerBook": 0.25,
    "bookCount": 4,
    "likeCount": 2,
    "commentCount": 1
  };
  constructor(private route:Router,private dashboard:DashboardServiceService){}
  ngOnInit(): void { 

    this.dashboard.getAllData().subscribe((obj)=>{
      this.dashBoard=obj;
      // let obj= this.dashBoard;
      this.maxReviewedBook=obj.maxReviewBooks;
      this.maxCommentedBook=obj.maxCommentBooks;
      this.maxLikedBook=obj.maxLikeBooks;
      this.avgLikesCount=obj.averageLikesPerBook;
      this.totalBooks=obj.bookCount;
      this.commentsCount=obj.commentCount;
      this.likesCount=obj.likeCount;

    });


  }


}
