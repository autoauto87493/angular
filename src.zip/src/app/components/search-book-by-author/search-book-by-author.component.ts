import { Component } from '@angular/core';
import { Book } from 'src/app/entity/Book';
import { BookService } from 'src/app/service/book.service';
import { SearchBookService } from 'src/app/service/search-book.service';

@Component({
  selector: 'app-search-book-by-author',
  templateUrl: './search-book-by-author.component.html',
  styleUrls: ['./search-book-by-author.component.css']
})
export class SearchBookByAuthorComponent {
  bookList:Book[]=[];
  search:number=0;
  author:string='';
  statusForEdit: boolean=false;
statusForView: boolean=false;
  constructor(private bookService:BookService,private searchBookService:SearchBookService){}
 
  searchBookByAuthor():void{
    if(this.author){
      this.searchBookService.searchBookByAuthor(this.author).subscribe(
        (b) => {
            if (b && b.length > 0) {
              
                this.bookList = b;  
                this.statusForView=true;
                //this.search = 1;  
            } else {
              
                this.bookList = [];  
                //this.search = 2;                    
            }
        });
  }
    else{
      alert("Please Enter Book Author");
    }
  }

editBook(book: Book) {
  this.statusForEdit=true;
  this.statusForView=false;
  sessionStorage.setItem('editableBook', JSON.stringify(book));
  
}
  
  deletedBook:Book=new Book();
  deleteBook(n:string) {
    this.bookService.deleteBook(n).subscribe((a)=>this.getBooks());
      
  }

  ngOnInit(){
    this.getBooks();
  }

  getBooks(){
    this.bookList;
  }

}
