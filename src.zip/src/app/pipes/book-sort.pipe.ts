import { Pipe, PipeTransform } from '@angular/core';
import { Book } from '../entity/Book';

@Pipe({
  name: 'bookSort'
})
export class BookSortPipe implements PipeTransform {

  transform(books:Book[],flag:number): any {
      switch(flag){
        case(1):
          return books.sort((a, b) => {
            return  a.price-b.price;
          });
          case(2):
          return books.sort((a: Book, b: Book) => {
            
            const avgRatingA = a.reviewList.length > 0 
                ? a.reviewList.reduce((sum, review) => sum + review.rating, 0) / a.reviewList.length 
                : 0;
                
            
            const avgRatingB = b.reviewList.length > 0 
                ? b.reviewList.reduce((sum, review) => sum + review.rating, 0) / b.reviewList.length 
                : 0;
        
            return avgRatingB - avgRatingA;
        });
        
          case(3):
          return books.sort((a, b) => {
            return  a.title.localeCompare(b.title);
          });
          case(4):
          return books.sort((a, b) => {
            return  a.author.localeCompare(b.author);
          });
          case(5):
          return books.sort((a, b) => {
            return a.year-b.year;
          });
        }
      }


  }


