export class Authorizer{
    loggedInTime:string='';
    token:string='';
    expireTime:string='';
    userId:string='';
}