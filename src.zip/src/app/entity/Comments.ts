import { Customer } from "./Customer";
 
export class Comments{
    public commentId:number=0;
    public comment:string='';
    public customer:Customer=new Customer();
    public commentTime:any;
}
 