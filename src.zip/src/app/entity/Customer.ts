 
export class Customer{
    public customerId:number=0;
    public name:string='';
    public email:string='';
    public password:string='';
}